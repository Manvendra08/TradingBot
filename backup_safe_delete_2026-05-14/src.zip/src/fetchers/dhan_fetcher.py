"""
Dhan API v2 Option Chain Fetcher (primary source).
Docs: https://dhanhq.co/docs/v2/option-chain/
"""
import logging
from datetime import datetime, timezone
from config.settings import (
    DHAN_CLIENT_ID, DHAN_ACCESS_TOKEN, DHAN_BASE_URL,
    DHAN_SECURITY_IDS
)
from src.fetchers.base_fetcher import BaseFetcher

log = logging.getLogger(__name__)

INDEX_SYMBOLS = {"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"}


class DhanFetcher(BaseFetcher):
    name = "dhan"

    def __init__(self):
        super().__init__()
        self.session.headers.update({
            "access-token": DHAN_ACCESS_TOKEN,
            "client-id":    DHAN_CLIENT_ID,
            "Content-Type": "application/json",
        })

    def _nearest_expiry(self, expiries: list[str]) -> str:
        """Return soonest expiry >= today."""
        today = datetime.now(timezone.utc).date()
        valid = [e for e in expiries if datetime.strptime(e, "%Y-%m-%d").date() >= today]
        return sorted(valid)[0] if valid else expiries[0]

    def fetch_option_chain(self, symbol: str) -> dict | None:
        security_id = DHAN_SECURITY_IDS.get(symbol)
        if not security_id:
            log.warning("[dhan] No security_id configured for %s", symbol)
            return None

        instrument = "IDX" if symbol in INDEX_SYMBOLS else "STK"
        payload = {"UnderlyingScrip": security_id, "UnderlyingSeg": instrument}

        # POST to /optionchain
        url = f"{DHAN_BASE_URL}/optionchain"
        try:
            r = self.session.post(url, json=payload, timeout=15)
            r.raise_for_status()
            raw = r.json()
        except Exception as exc:
            log.error("[dhan] fetch failed for %s: %s", symbol, exc)
            return None

        return self._normalise(symbol, raw)

    def _normalise(self, symbol: str, raw: dict) -> dict | None:
        try:
            data          = raw.get("data", {})
            underlying    = float(data.get("last_price", 0))
            expiries      = data.get("expiry_list", [])
            expiry        = self._nearest_expiry(expiries)
            oc_data       = data.get("oc_data", {}).get(expiry, [])

            strikes = []
            for entry in oc_data:
                strike = float(entry.get("strike_price", 0))
                for ot in ("CE", "PE"):
                    opt = entry.get(ot, {})
                    if not opt:
                        continue
                    strikes.append({
                        "strike":     strike,
                        "option_type": ot,
                        "ltp":        float(opt.get("last_price", 0) or 0),
                        "oi":         int(opt.get("oi", 0) or 0),
                        "oi_change":  int(opt.get("oi_change", 0) or 0),
                        "volume":     int(opt.get("volume", 0) or 0),
                        "iv":         float(opt.get("implied_volatility", 0) or 0),
                        "bid":        float(opt.get("bid_price", 0) or 0),
                        "ask":        float(opt.get("ask_price", 0) or 0),
                    })

            return {
                "symbol":           symbol,
                "underlying_price": underlying,
                "expiry":           expiry,
                "strikes":          strikes,
                "source":           self.name,
            }
        except Exception as exc:
            log.error("[dhan] normalise failed for %s: %s", symbol, exc)
            return None
