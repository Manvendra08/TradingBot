/**
 * tv_content.js — NSEBOT Chart Scraper v16.2 (Resilient Edition)
 */
'use strict';

if (!window.__NSEBOT_SCRAPER_V16) {
  window.__NSEBOT_SCRAPER_V16 = true;

  const SCRAPE_INTERVAL_MS = 5000;
  const STORAGE_KEY = 'nsebot_chart_data';
  const DEBUG_KEY = 'nsebot_chart_debug';
  let lastDataSerialized = '';

  function debug(stage, extra = {}) {
    chrome.storage.local.set({
      [DEBUG_KEY]: {
        stage,
        url: window.location.href,
        title: document.title || '',
        at: new Date().toISOString(),
        ...extra
      }
    });
  }

  // ── Sentiment Engine ────────────────────────────────────────────────────────
  function extractSentiment(el) {
    if (!el) return 'NEUTRAL';
    const text = (el.innerText || el.textContent || '').replace(/\s+/g, ' ');
    if (/(^|\s)\+\d/.test(text) || /\(\+\d/.test(text)) return 'BULLISH';
    if (/(^|\s)-\d/.test(text) || /\(-\d/.test(text)) return 'BEARISH';

    const targets = [el, ...el.querySelectorAll('*')];
    for (const node of targets) {
      const style = window.getComputedStyle(node);
      const colorInfo = (style.backgroundColor + ' ' + style.color).toLowerCase();
      
      if (colorInfo.includes('8, 153, 129') || colorInfo.includes('38, 166, 154') || colorInfo.includes('0, 150, 136') || colorInfo.includes('76, 175, 80') || colorInfo.includes('green') || colorInfo.includes('teal')) return 'BULLISH';
      if (colorInfo.includes('242, 54, 69') || colorInfo.includes('239, 83, 80') || colorInfo.includes('255, 82, 82') || colorInfo.includes('244, 67, 54') || colorInfo.includes('red') || colorInfo.includes('orange')) return 'BEARISH';
    }
    return 'NEUTRAL';
  }

  function numberNearText(text, label) {
    const re = new RegExp(`${label}[^\\d-]*(-?\\d[\\d,]*(?:\\.\\d+)?)`, 'i');
    const m = String(text || '').match(re);
    return m ? parseLegendNumber(m[1]) : null;
  }

  function escapeRe(s) {
    return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function sentimentFromSignedChange(text) {
    const m = String(text || '').match(/([+-]\d[\d,]*(?:\.\d+)?)\s*\(([+-]\d[\d,]*(?:\.\d+)?)%\)/);
    if (!m) return null;
    const change = parseLegendNumber(m[1]);
    const pct = parseLegendNumber(m[2]);
    const n = change !== 0 ? change : pct;
    if (n > 0) return { sentiment: 'BULLISH', change, pct };
    if (n < 0) return { sentiment: 'BEARISH', change, pct };
    return { sentiment: 'NEUTRAL', change, pct };
  }

  function visibleTfSignals(symbol) {
    const body = (document.body?.innerText || document.body?.textContent || '')
      .replace(/\s+/g, ' ')
      .toUpperCase();
    const sym = escapeRe(symbol);
    const out = {};

    ['1H', '3H'].forEach(tf => {
      const patterns = [
        new RegExp(`${sym}.{0,160}\\b${tf}\\b.{0,220}?([+-]\\d[\\d,]*(?:\\.\\d+)?)\\s*\\(([+-]\\d[\\d,]*(?:\\.\\d+)?)%\\)`, 'i'),
        new RegExp(`\\b${tf}\\b.{0,160}${sym}.{0,220}?([+-]\\d[\\d,]*(?:\\.\\d+)?)\\s*\\(([+-]\\d[\\d,]*(?:\\.\\d+)?)%\\)`, 'i'),
        new RegExp(`\\b${tf}\\b.{0,260}?([+-]\\d[\\d,]*(?:\\.\\d+)?)\\s*\\(([+-]\\d[\\d,]*(?:\\.\\d+)?)%\\)`, 'i')
      ];
      for (const re of patterns) {
        const m = body.match(re);
        if (!m) continue;
        const sig = sentimentFromSignedChange(`${m[1]} (${m[2]}%)`);
        if (sig) {
          out[tf.toLowerCase()] = sig;
          break;
        }
      }
    });

    if (!out['1h'] || !out['3h']) {
      const matches = [...body.matchAll(/\b(1H|3H)\b.{0,260}?([+-]\d[\d,]*(?:\.\d+)?)\s*\(([+-]\d[\d,]*(?:\.\d+)?)%\)/gi)];
      matches.forEach(m => {
        const tf = m[1].toLowerCase();
        if (out[tf]) return;
        const sig = sentimentFromSignedChange(`${m[2]} (${m[3]}%)`);
        if (sig) out[tf] = sig;
      });
    }

    return out;
  }

  function inferSentiment(item, container, ohlc, refPrice) {
    const itemText = item?.innerText || item?.textContent || '';
    const allText = [itemText, container?.innerText || container?.textContent || ''].join(' ');

    const explicit = extractSentiment(item);
    if (explicit !== 'NEUTRAL') return explicit;

    const change = allText.match(/([+-]\d[\d,]*(?:\.\d+)?)\s*\(([+-]\d[\d,]*(?:\.\d+)?)%\)/);
    if (change) {
      const n = parseLegendNumber(change[1]);
      if (n > 0) return 'BULLISH';
      if (n < 0) return 'BEARISH';
    }

    if (ohlc?.open && ohlc?.close) {
      if (ohlc.close > ohlc.open) return 'BULLISH';
      if (ohlc.close < ohlc.open) return 'BEARISH';
    }

    const close = ohlc?.close || refPrice;
    const st = numberNearText(allText, 'SuperTrend');
    if (close && st) {
      if (st < close) return 'BULLISH';
      if (st > close) return 'BEARISH';
    }

    return 'NEUTRAL';
  }

  // ── Timeframe Normalization ────────────────────────────────────────────────
  function normTF(t) {
    if (!t) return '—';
    const s = t.toLowerCase().replace(/\s+/g, '');
    const map = {
      '1h': '1h', '60': '1h', '60m': '1h',
      '3h': '3h', '180': '3h', '180m': '3h',
      '4h': '4h', '240': '4h', '240m': '4h',
      '1d': '1d', 'd': '1d',
      '15m': '15m', '15': '15m',
      '5m': '5m', '5': '5m',
      '30m': '30m', '30': '30m'
    };
    return map[s] || '—';
  }

  // Squash-proof regex: Finds timeframes even if attached to letters (e.g. "FUT1h")
  function findTimeframe(text) {
    const match = text.toUpperCase().match(/(?:^|[^0-9])(\d{1,3}[MHD]|1[DWM])(?:$|[^A-Z0-9])/);
    if (match && match[1]) return normTF(match[1].toLowerCase());
    return '—';
  }

  function cleanSymbolText(raw) {
    let text = String(raw || '').toUpperCase().replace(/\s+/g, ' ').trim();
    if (!text) return null;

    const contract = text.match(/\b([A-Z][A-Z0-9-]{1,20}\s+(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)\s+FUT)\b/);
    if (contract) return contract[1].trim();

    text = text.split(/[\d,]+(?:\.\d+)?\s*\(/)[0];
    text = text
      .replace(/[|•]/g, ' ')
      .replace(/\s+-\s+(DHAN|TRADINGVIEW).*$/i, '')
      .replace(/\b(DHAN|TRADINGVIEW|ADVANCED|REAL[- ]?TIME|CHARTS?|OPTIONS?|LOADING)\b/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (/^[A-Z][A-Z0-9 &:\-!]{1,40}$/.test(text)) return text;
    return null;
  }

  // ── Symbol Extraction ──────────────────────────────────────────────
  function extractSymbol() {
    // 1. URL params used by TradingView embeds / Dhan wrappers.
    try {
      const params = new URL(window.location.href).searchParams;
      for (const key of ['symbol', 'tvwidgetsymbol', 's']) {
        const clean = cleanSymbolText(params.get(key));
        if (clean) return clean;
      }
    } catch (_) {}

    // 2. Top-frame title fallback, tolerant of "... - Dhan" suffixes.
    const titleSym = cleanSymbolText(document.title);
    if (titleSym) return titleSym;

    // 3. Iframe / Legend fallback
    const titleSelectors = [
      '[data-name="legend-series-item"] [data-name="legend-title"]',
      '[class*="legendTitle"]',
      '[class*="mainSourceWrapper"] [class*="title"]',
      '.chart-title-text'
    ];
    for (const sel of titleSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        const clean = cleanSymbolText(el.innerText || el.textContent);
        if (clean) return clean;
      }
    }

    const bodyText = (document.body?.innerText || document.body?.textContent || '').slice(0, 20000);
    const bodySym = cleanSymbolText(bodyText);
    if (bodySym) return bodySym;

    return null;
  }

  function parseLegendNumber(raw) {
    const n = parseFloat(String(raw || '').replace(/,/g, ''));
    return Number.isFinite(n) ? n : null;
  }

  function refPriceFromSnapshot(snap) {
    const vals = [snap?.underlying, snap?.underlying_price, snap?.summary?.underlying];
    for (const v of vals) {
      const n = Number(v);
      if (Number.isFinite(n) && n > 0) return n;
    }
    return null;
  }

  // ── OHLC Extraction (Resilient) ────────────────────────────────────────────
  function extractOHLC(paneItem, refPrice = null) {
    try {
      const valNode = paneItem.querySelector('[class*="valuesWrapper"], [class*="seriesValues"]');
      if (!valNode) return null;
      
      const text = (valNode.innerText || valNode.textContent).toUpperCase().replace(/\s+/g, ' ');
      
      const ohlc = {};
      const labelRe = /(?:^|[\s,])([OHLC])(?:\s*[:=]|\s+)(-?\d[\d,]*(?:\.\d+)?)/g;
      let m;
      while ((m = labelRe.exec(text)) !== null) {
        const n = parseLegendNumber(m[2]);
        if (n != null) {
          if (m[1] === 'O') ohlc.open = n;
          if (m[1] === 'H') ohlc.high = n;
          if (m[1] === 'L') ohlc.low = n;
          if (m[1] === 'C') ohlc.close = n;
        }
      }

      if (ohlc.close && ohlc.open && ohlc.high && ohlc.low) return ohlc;
      if (ohlc.close) return { close: ohlc.close };

      const nums = (text.match(/-?\d[\d,]*(?:\.\d+)?/g) || [])
        .map(parseLegendNumber)
        .filter(n => n != null);

      if (refPrice) {
        const near = nums
          .filter(n => n > 0 && Math.abs(n - refPrice) / refPrice <= 0.20)
          .sort((a, b) => Math.abs(a - refPrice) - Math.abs(b - refPrice));
        if (near.length) return { close: near[0] };
      }
    } catch(e) {}
    return null;
  }

  // ── Built-Up Data Extraction ──────────────────────────────────────────────
  function extractBuiltUpTable() {
    const modalTitle = Array.from(document.querySelectorAll('*')).find(el => 
        el.textContent.trim() === '15 - Minutes Built-up'
    );
    if (!modalTitle) return null;

    const headerEl = Array.from(document.querySelectorAll('th, td, div')).find(el =>
      el.textContent.includes('Trading Zone') && el.textContent.includes('OI Chg')
    );
    if (!headerEl) return null;

    let rows = [];
    const tableContainer = headerEl.closest('table');
    
    if (tableContainer) {
      rows = Array.from(tableContainer.querySelectorAll('tr'));
    } else {
      const intervalRegex = /^\d{2}:\d{2}\s*-\s*\d{2}:\d{2}$/;
      const intervalDivs = Array.from(document.querySelectorAll('div')).filter(div => 
          intervalRegex.test(div.textContent.trim()) && div.children.length === 0
      );
      if (intervalDivs.length > 0) rows = [...new Set(intervalDivs.map(div => div.parentElement))];
    }

    const parsedData = [];
    const intervalRegex = /^\d{2}:\d{2}\s*-\s*\d{2}:\d{2}$/;

    rows.forEach(row => {
      const cells = Array.from(row.querySelectorAll('td, > div'));
      if (cells.length >= 8) {
        const intervalText = (cells[0].innerText || cells[0].textContent).trim();
        if (intervalRegex.test(intervalText)) {
          parsedData.push({
            interval: intervalText,
            trading_zone: (cells[1].innerText || cells[1].textContent).trim(),
            price_range: (cells[2].innerText || cells[2].textContent).trim(),
            oi: parseInt((cells[3].innerText || cells[3].textContent).replace(/,/g, ''), 10) || 0,
            oi_chg_pct: (cells[4].innerText || cells[4].textContent).trim(),
            fresh: parseInt((cells[5].innerText || cells[5].textContent).replace(/,/g, ''), 10) || 0,
            square_off: parseInt((cells[6].innerText || cells[6].textContent).replace(/,/g, ''), 10) || 0,
            volume: parseInt((cells[7].innerText || cells[7].textContent).replace(/,/g, ''), 10) || 0
          });
        }
      }
    });
    return parsedData.length > 0 ? parsedData : null;
  }

  // ── Core Scraper ───────────────────────────────────────────────────────────
  let scrapeInterval;

  function scrape() {
    if (!chrome.runtime?.id) {
      if (scrapeInterval) clearInterval(scrapeInterval);
      return;
    }

    const symbol = extractSymbol();
    if (!symbol) {
      debug('no_symbol');
      return;
    }

    scrapeForSymbol(symbol);
  }

  function scrapeForSymbol(symbol) {
    const seriesSelectors = [
      '[data-name="legend-series-item"]',
      '[class*="legendMainSourceWrapper"]',
      '[class*="mainSourceWrapper"]'
    ];
    const liveSignals = visibleTfSignals(symbol);
    
    let seriesItems = [];
    for (const sel of seriesSelectors) {
      const found = document.querySelectorAll(sel);
      if (found.length > 0) { seriesItems = [...found]; break; }
    }
    if (!seriesItems.length) {
      seriesItems = Array.from(document.querySelectorAll(
        '.chart-container, .layout__area--center, .chart-markup-table, [class*="pane"], [class*="chart-container"]'
      )).filter(el => (el.innerText || el.textContent || '').trim().length > 20);
    }

    debug('scrape_start', { symbol, seriesItems: seriesItems.length });

    chrome.storage.local.get([STORAGE_KEY, 'nsebot_snapshot'], (res) => {
      if (chrome.runtime.lastError) {
        debug('storage_read_error', { error: chrome.runtime.lastError.message });
        return;
      }

      const fullData = res[STORAGE_KEY] || {};
      for (const key of Object.keys(fullData)) {
        if (key !== symbol) delete fullData[key];
      }
      const refPrice = refPriceFromSnapshot(res.nsebot_snapshot);
      const currentSymData = fullData[symbol] || {};
      const seenAt = new Date().toISOString();
      let hasSeen = false;
      let dataChanged = false;
      let foundPane = false;

      if (seriesItems.length > 0) {
        seriesItems.forEach(item => {
          const text = (item.innerText || item.textContent).trim();
          let timeframe = findTimeframe(text);
          
          if (timeframe === '—') {
            const btn = document.querySelector('[data-name="time-interval-dialog-button"], [class*="interval"][class*="button"]');
            if (btn) timeframe = normTF((btn.innerText || btn.textContent).trim());
          }
          if (timeframe === '—') return; // If STILL empty, skip this pane

          foundPane = true;
          const container = item.closest('[data-name="legend"]') || item.closest('[class*="legendContainer"]') || item.parentElement;
          let sentiment = extractSentiment(item);
          const indicators = [];

          if (container) {
            const sourceItems = container.querySelectorAll('[data-name="legend-source-item"], [class*="sourceItem"]');
            sourceItems.forEach(src => {
              const srcText = (src.innerText || src.textContent).trim();
              let srcSent = extractSentiment(src);
              
              const cleanName = srcText.split(/[0-9]/)[0].trim();
              if (cleanName) indicators.push({ name: cleanName, sentiment: srcSent });
            });
          }

          const ohlc = extractOHLC(item, refPrice);
          const liveSig = liveSignals[timeframe] || sentimentFromSignedChange(text);
          sentiment = liveSig?.sentiment || (ohlc?.open && ohlc?.close
            ? (ohlc.close > ohlc.open ? 'BULLISH' : ohlc.close < ohlc.open ? 'BEARISH' : 'NEUTRAL')
            : inferSentiment(item, container, ohlc, refPrice));
          if (liveSignals[timeframe]) sentiment = liveSignals[timeframe].sentiment;
          indicators.forEach(ind => {
            if ((ind.name || '').toUpperCase().includes('SUPERTREND') && ind.sentiment === 'NEUTRAL') {
              ind.sentiment = sentiment;
            }
          });
          const newEntry = { sentiment, indicators, ohlc };
          const oldEntry = currentSymData[timeframe];
          
          const payloadChanged = !oldEntry || 
                                 oldEntry.sentiment !== newEntry.sentiment || 
                                 oldEntry.indicators.length !== newEntry.indicators.length ||
                                 JSON.stringify(oldEntry.indicators) !== JSON.stringify(newEntry.indicators) ||
                                 JSON.stringify(oldEntry.ohlc) !== JSON.stringify(newEntry.ohlc);

          if (payloadChanged) {
            currentSymData[timeframe] = { ...newEntry, seen_at: seenAt, changed_at: seenAt, updated_at: seenAt };
            dataChanged = true;
          } else {
            currentSymData[timeframe] = {
              ...oldEntry,
              seen_at: seenAt,
              changed_at: oldEntry.changed_at || oldEntry.updated_at || null,
              updated_at: oldEntry.changed_at || oldEntry.updated_at || null
            };
          }
          hasSeen = true;
        });
      }

      Object.entries(liveSignals).forEach(([tf, sig]) => {
        const prev = currentSymData[tf] || { indicators: [] };
        if (prev.sentiment !== sig.sentiment) {
          currentSymData[tf] = {
            ...prev,
            sentiment: sig.sentiment,
            live_change: sig.change,
            live_pct: sig.pct,
            seen_at: seenAt,
            changed_at: seenAt,
            updated_at: seenAt
          };
          dataChanged = true;
        } else {
          currentSymData[tf] = {
            ...prev,
            live_change: sig.change,
            live_pct: sig.pct,
            seen_at: seenAt,
            changed_at: prev.changed_at || prev.updated_at || null,
            updated_at: prev.changed_at || prev.updated_at || null
          };
        }
        hasSeen = true;
      });

      if (!foundPane) {
        const btn = document.querySelector('[data-name="time-interval-dialog-button"], [class*="interval"][class*="button"]');
        if (btn) {
          const tf = normTF((btn.innerText || btn.textContent).trim());
          if (tf !== '—') {
            const prev = currentSymData[tf] || { sentiment: 'NEUTRAL', indicators: [] };
            currentSymData[tf] = {
              ...prev,
              seen_at: seenAt,
              changed_at: prev.changed_at || prev.updated_at || null,
              updated_at: prev.changed_at || prev.updated_at || null
            };
            hasSeen = true;
          }
        }
      }

      const builtUpData = extractBuiltUpTable();
      if (builtUpData) {
        const oldBuiltUp = currentSymData['built_up']?.data;
        if (!oldBuiltUp || JSON.stringify(oldBuiltUp[0]) !== JSON.stringify(builtUpData[0])) {
          currentSymData['built_up'] = { data: builtUpData, seen_at: seenAt, changed_at: seenAt, updated_at: seenAt };
          dataChanged = true;
        } else if (currentSymData['built_up']) {
          currentSymData['built_up'].seen_at = seenAt;
          hasSeen = true;
        }
      }

      if (hasSeen || dataChanged) {
        fullData[symbol] = currentSymData;
        const serialized = `${symbol}:${JSON.stringify(fullData[symbol])}`;
        
        if (serialized !== lastDataSerialized) {
          lastDataSerialized = serialized;
          chrome.storage.local.set({
            [STORAGE_KEY]: fullData,
            'last_chart_symbol': symbol,
            'nsebot_site': 'dhan_chart'
          }, () => {
            const err = chrome.runtime.lastError;
            if (err) debug('storage_write_error', { symbol, error: err.message });
            else debug(dataChanged ? 'changed' : 'seen', { symbol, keys: Object.keys(currentSymData) });
            console.log(`[NSEBOT v16.2] Scraped ${symbol} — payload updated`);
          });
        }
        if (serialized === lastDataSerialized) {
          chrome.storage.local.set({
            [STORAGE_KEY]: fullData,
            'last_chart_symbol': symbol,
            'nsebot_site': 'dhan_chart'
          }, () => debug('seen', { symbol, keys: Object.keys(currentSymData) }));
        }
      } else {
        chrome.storage.local.set({
          'last_chart_symbol': symbol,
          'nsebot_site': 'dhan_chart'
        }, () => debug('refreshed_ref', { symbol, seriesItems: seriesItems.length, foundPane }));
      }
    });
  }

  console.log(`[NSEBOT v16.2] Initializing on ${window.location.hostname}`);
  [1000, 3000, 6000].forEach(ms => setTimeout(() => { if (chrome.runtime?.id) scrape(); }, ms));
  scrapeInterval = setInterval(scrape, SCRAPE_INTERVAL_MS);

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!chrome.runtime?.id) return;
    if (msg.type === 'FORCE_SCAN') { scrape(); sendResponse({ ok: true }); }
    if (msg.type === 'PING') sendResponse({ pong: true });
  });
}
